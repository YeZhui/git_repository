#include "stdafx.h"
#include "SqliteManager.h"
#include "UtilString.h"

#pragma warning(disable: 4996)

CSqliteManager::CSqliteManager()
	:m_pDb(NULL)
	,m_pStmt(NULL)
{
	m_strDBName = "md5.db";
}

CSqliteManager::~CSqliteManager()
{
	CloseDB();
}

int CSqliteManager::OpenDB(std::string strDBName)
{
	if (strDBName.size() != 0)
	{
		m_strDBName = strDBName;
	}
	int ret = sqlite3_open(m_strDBName.c_str(), &m_pDb);
	if (ret != SQLITE_OK)
	{
		sqlite3_close(m_pDb);
		popUpBox("sqlite3_open %s failed",m_strDBName.c_str());
		return -1;
	}
	return 0;
}

int CSqliteManager::PrepareDB(const char* sql)
{
	int ret = sqlite3_prepare_v2(m_pDb,sql,-1,&m_pStmt,NULL);
	if (ret != SQLITE_OK)
	{
		CloseDB();
		popUpBox("sqlite3_prepare:%s failed",sql);
		return -1;
	}
	return 0;
}

int CSqliteManager::ExecDB(const char* sql)
{
	char *szErrMsg = NULL;
	int ret = sqlite3_exec(m_pDb,sql,NULL,NULL,&szErrMsg);
	if (ret != SQLITE_OK)
	{
			CloseDB();
			popUpBox("sqlite3_exec failed:%s",szErrMsg);
			return -1;
	}
	return 0;
}

//example:select encryData from table where decryData=''
//only select single record
//return value:0   no result but success,1  have result,2 error
int CSqliteManager::SelectDB(const char* sql, std::string& strRet)
{
	strRet.clear();
	int ret = PrepareDB(sql);
	if (ret == 0)
	{
		ret = sqlite3_step(m_pStmt);
		if ( SQLITE_ROW == ret )
		{
			strRet = (const char*)sqlite3_column_text(m_pStmt,0);
			return 1;
		}
		if (SQLITE_DONE == ret )
		{
			return 0;
		}
		else
			return 2;
	}
	return 2;
}

int CSqliteManager::CloseDB()
{
	if (m_pStmt != NULL)
	{
		sqlite3_finalize(m_pStmt);
		m_pStmt = NULL;
	}
	if (m_pDb != NULL)
	{
		sqlite3_close(m_pDb);
		m_pDb = NULL;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////

//CExecSql::~CExecSql()
//{
//}

CExecSql* CExecSql::m_pInstance = NULL;

CExecSql& CExecSql::GetInstance()
{
	if ( m_pInstance == NULL)
	{
		m_pInstance = new CExecSql();
		atexit(CExecSql::DestroyInstance);
	}
	return *m_pInstance;
}

void CExecSql::DestroyInstance()
{
	if (m_pInstance != NULL)
	{
		delete m_pInstance;
		m_pInstance = NULL;
	}
}

/*
sqlType:
1   select
2   update,insert,delete
*/
std::string CExecSql::ExecSql(const char* sql, int sqlType)
{
	std::string strRet("");
	CSqliteManager sqliteDb;
	sqliteDb.OpenDB();
	if (sqlType == 1)
	{
		int ret = sqliteDb.SelectDB(sql,strRet);
		if (ret == 0)
		{
			strRet = "";
		}
		if (ret == 2)
		{
			strRet = "error";
		}
	}
	if (sqlType == 2)
	{
		sqliteDb.ExecDB(sql);
	}
	sqliteDb.CloseDB();
	return strRet;
}

//////////////////////////////////////////////////////////////////

inline void popUpBox(const char* outStr, const char* paramStr)
{
	char popUpStr[256] = {0};
	if (strlen(paramStr) > 0)
	{
		_snprintf(popUpStr, sizeof(popUpStr)-1, outStr, paramStr);
	}
	else
	{
		strncpy(popUpStr, outStr, sizeof(popUpStr)-1);
	}
	std::wstring wstrPopUp = UtilString::ConvertMultiByteToWideChar(std::string(popUpStr));
	AfxMessageBox(wstrPopUp.c_str(), MB_OKCANCEL|MB_ICONSTOP);
}

