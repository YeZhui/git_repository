﻿#pragma once

#include "..\sqlitelib\sqlite3.h"
#include <string>

class CSqliteManager
{
public:
	CSqliteManager();
	~CSqliteManager();

	int OpenDB(std::string strDBName = "");
	int ExecDB(const char* sql);  //执行没有结果集的sql语句
	//int Callback(void* NotUsed, int argc, char** argv, char**azColName);
	int SelectDB(const char* sql, std::string& strRet);  //exec select sql
	int CloseDB();

private:
	int PrepareDB(const char* sql);

private:
	sqlite3*       m_pDb;
	sqlite3_stmt*  m_pStmt;
	std::string    m_strDBName;
};

class CExecSql
{
public:
	//virtual ~CExecSql();
	static CExecSql& GetInstance();
	static void DestroyInstance();
	std::string ExecSql(const char* sql, int sqlType);

private:
	static CExecSql*  m_pInstance;
};

void popUpBox(const char* outStr, const char* paramStr = "");