#pragma once
#include <string>

// CConvertPage dialog

class CConvertPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CConvertPage)

public:
	CConvertPage();
	virtual ~CConvertPage();

// Dialog Data
	enum { IDD = IDD_CONVERT_PAGE };

	virtual void RecalLayout(void);
	virtual	BOOL OnInitDialog();

	std::string GetEncryptFromSrcData(unsigned char* srcData, int byteType);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg void OnBnClickedEncrypt();
	afx_msg void OnBnClickedDecrypt();

	DECLARE_MESSAGE_MAP()

private:
	CEdit         m_editSrcData;
	CEdit         m_editDestData;
	CEdit         m_editEncryptData;
	CEdit         m_editDecryptData;

	CButton       m_buttonEncrypt;
	CButton       m_buttonDecrypt;
};
