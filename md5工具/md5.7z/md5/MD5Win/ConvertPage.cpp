// ConvertPage.cpp : implementation file
//

#include "stdafx.h"
#include "MD5Win.h"
#include "ConvertPage.h"
#include "afxdialogex.h"
#include "UtilString.h"
#include <string.h>
#include "Md5.h"
#include "SqliteManager.h"

#pragma warning(disable: 4996)

// CConvertPage dialog

IMPLEMENT_DYNAMIC(CConvertPage, CPropertyPage)

CConvertPage::CConvertPage()
	: CPropertyPage(CConvertPage::IDD)
{

}

CConvertPage::~CConvertPage()
{
}

void CConvertPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SRC_DATA, m_editSrcData);
	DDX_Control(pDX, IDC_DEST_DATA, m_editDestData);
	DDX_Control(pDX, IDC_ENCRYPT_DATA, m_editEncryptData);
	DDX_Control(pDX, IDC_DECRYPT_DATA, m_editDecryptData);
	DDX_Control(pDX, IDC_MD5_ENCRYPT, m_buttonEncrypt);
	DDX_Control(pDX, IDC_MD5_DECRYPT, m_buttonDecrypt);
}


BEGIN_MESSAGE_MAP(CConvertPage, CPropertyPage)
	ON_BN_CLICKED(IDC_MD5_ENCRYPT, &CConvertPage::OnBnClickedEncrypt)
	ON_BN_CLICKED(IDC_MD5_DECRYPT, &CConvertPage::OnBnClickedDecrypt)
END_MESSAGE_MAP()

BOOL CConvertPage::OnInitDialog()
{
	CPropertyPage::OnInitDialog();
	GetDlgItem(IDC_HELP_ENTER)->ShowWindow(false);
	RecalLayout();
	return TRUE;
}

std::string CConvertPage::GetEncryptFromSrcData(unsigned char* srcData, int byteType)
{
	MD5_CTX md5;
	memset(&md5,0,sizeof(md5));
	//unsigned char encrypt[100] = {0};
	unsigned char decrypt[17] = {0};
	char result[64] = {0};

	MD5Init(&md5);
	MD5Update(&md5, srcData, strlen((char*)srcData));
	MD5Final(decrypt,&md5);

	char*p = result;
	if (byteType == 16)
	{
		for(int i=4;i<12;i++)
		{
			_snprintf(p,2,"%02x",decrypt[i]);
			p += 2;
		}
	}
	else
	{
		for(int i=0;i<16;i++)
		{
			_snprintf(p,2,"%02x",decrypt[i]);
			p += 2;
		}
	}
	return result;
}

void CConvertPage::OnBnClickedEncrypt()
{
	unsigned char encrypt[100] = {0};
	CString cstrSrcData;
	std::string strSql = "insert into encrypt_decrypt values(\'";
	std::string strSelectSql = "select encrypt_data_16 from encrypt_decrypt where src_data = \'";

	m_editSrcData.GetWindowText(cstrSrcData);
	std::string strEncrypt = UtilString::ConvertWideCharToMultiByte(cstrSrcData.GetString());
	strncpy((char*)encrypt, strEncrypt.c_str(), sizeof(encrypt)-1);

	std::string strDestData_16 = GetEncryptFromSrcData(encrypt,16);
	std::string strDestData_32 = GetEncryptFromSrcData(encrypt,32);
	strSelectSql += (char*)encrypt;
	strSelectSql += "\';";

	strSql += (char*)encrypt;
	strSql += "\',\'";

	strSql += strDestData_16;
	std::wstring wstrDecrypt = UtilString::ConvertMultiByteToWideChar(strDestData_16);
	CString cstrDestData(wstrDecrypt.c_str());
	m_editDestData.SetWindowTextW(cstrDestData);

	strSql += "\',\'";
	strSql += strDestData_32;
	std::wstring wstr32Data = UtilString::ConvertMultiByteToWideChar(strDestData_32);
	CString cstrDest32Data(wstr32Data.c_str());
	GetDlgItem(IDC_DEST_32DATA)->SetWindowTextW(cstrDest32Data);
	strSql += "\');";
	if ( CExecSql::GetInstance().ExecSql(strSelectSql.c_str(),1).size() == 0)
	{
		CExecSql::GetInstance().ExecSql(strSql.c_str(),2);
	}
}

void CConvertPage::OnBnClickedDecrypt()
{
	CString cstrEncryptData;
	m_editEncryptData.GetWindowText(cstrEncryptData);
	std::string strEncrypt = UtilString::ConvertWideCharToMultiByte(cstrEncryptData.GetString());
	std::string sql = "select src_data from encrypt_decrypt where ";
	if (strEncrypt.size() == 16)
	{
		sql += "encrypt_data_16 = \'";
	}
	else
	{
		sql += "encrypt_data_32 = \'";
	}
	sql += strEncrypt;
	sql += "\';";
	std::string strSrcData = CExecSql::GetInstance().ExecSql(sql.c_str(),1);
	std::wstring wstrSrcData = UtilString::ConvertMultiByteToWideChar(strSrcData);
	CString cstrSrcData(wstrSrcData.c_str());
	m_editDecryptData.SetWindowTextW(cstrSrcData);
}
// CConvertPage message handlers


void CConvertPage::RecalLayout(void)
{
	if (m_hWnd == NULL || !IsWindow(m_hWnd) )
		return;
	CPropertySheet *pSheet = dynamic_cast<CPropertySheet*>(GetParent());
	if (pSheet == NULL)
		return;
	CRect rtTab;
	pSheet->GetClientRect(&rtTab);
	rtTab.DeflateRect(-2, 0, -2, -2);
	pSheet->GetTabControl()->MoveWindow(&rtTab);

	CRect rtPage;
	rtPage.left = rtTab.left + 10;
	rtPage.top = rtTab.top + 25;
	rtPage.right = rtTab.right - 10;
	rtPage.bottom = rtTab.bottom - 10;
	MoveWindow(rtPage);

	CRect rtClient;
	GetClientRect(&rtClient);

	//IDC_ENCRYPT
	CRect rtEncryptGroup;
	rtEncryptGroup.left = rtClient.left + 10;
	rtEncryptGroup.top = rtClient.top + 15;
	rtEncryptGroup.right = rtClient.right - 40;
	rtEncryptGroup.bottom = rtClient.top + 200;
	GetDlgItem(IDC_ENCRYPT)->MoveWindow(rtEncryptGroup);
	//IDC_SRC_DATA
	CRect rtSrcData;
	rtSrcData.left = rtEncryptGroup.left + 20;
	rtSrcData.right = rtEncryptGroup.right/2 + 100;
	rtSrcData.top = rtEncryptGroup.top + 25;
	rtSrcData.bottom = rtEncryptGroup.top + 50;
	m_editSrcData.MoveWindow(rtSrcData);
	//IDC_MD5_ENCRYPT
	CRect rtEncryptButton;
	rtEncryptButton.left = rtSrcData.right + 15;
	rtEncryptButton.right = rtEncryptButton.left + 80;
	rtEncryptButton.top = rtSrcData.top;
	rtEncryptButton.bottom = rtSrcData.bottom;
	m_buttonEncrypt.MoveWindow(rtEncryptButton);
	//IDC_STATIC_16
	CRect rtStatic16;
	rtStatic16.left = rtSrcData.left;
	rtStatic16.right = rtStatic16.left + 100;
	rtStatic16.top = rtSrcData.bottom + 10;
	rtStatic16.bottom = rtStatic16.top + 15;
	GetDlgItem(IDC_STATIC_16)->MoveWindow(rtStatic16);
	//IDC_DEST_DATA
	CRect rt16DestData;
	rt16DestData.left = rtSrcData.left;
	rt16DestData.right = rtSrcData.right;
	rt16DestData.top = rtStatic16.bottom + 10;
	rt16DestData.bottom = rt16DestData.top + 25;
	m_editDestData.MoveWindow(rt16DestData);
	//IDC_STATIC_32
	CRect rtStatic32;
	rtStatic32 = rtStatic16;
	rtStatic32.top = rt16DestData.bottom + 10;
	rtStatic32.bottom = rtStatic32.top + 15;
	GetDlgItem(IDC_STATIC_32)->MoveWindow(rtStatic32);
	//IDC_DEST_32DATA
	CRect rtDest32Data;
	rtDest32Data = rt16DestData;
	rtDest32Data.top = rtStatic32.bottom + 10;
	rtDest32Data.bottom = rtDest32Data.top + 25;
	GetDlgItem(IDC_DEST_32DATA)->MoveWindow(rtDest32Data);

	//IDC_DECRYPT
	CRect rtDecryptGroup;
	rtDecryptGroup.left = rtEncryptGroup.left;
	rtDecryptGroup.right = rtEncryptGroup.right;
	rtDecryptGroup.top = rtEncryptGroup.bottom + 15;
	rtDecryptGroup.bottom = rtDecryptGroup.top + 105;
	GetDlgItem(IDC_DECRYPT)->MoveWindow(rtDecryptGroup);
	//IDC_HELP_ENTER
	//CRect rtHelpEnter;
	//IDC_ENCRYPT_DATA
	CRect rtEncryptData;
	rtEncryptData.left = rtSrcData.left;
	rtEncryptData.right = rtSrcData.right;
	rtEncryptData.top = rtDecryptGroup.top + 25;
	rtEncryptData.bottom = rtEncryptData.top + 25;
	m_editEncryptData.MoveWindow(rtEncryptData);
	//IDC_MD5_DECRYPT
	CRect rtDecryptButton;
	rtDecryptButton = rtEncryptButton;
	rtDecryptButton.top = rtEncryptData.top;
	rtDecryptButton.bottom = rtEncryptData.bottom;
	m_buttonDecrypt.MoveWindow(rtDecryptButton);
	//IDC_DECRYPT_DATA
	CRect rtDecryptData;
	rtDecryptData.left = rtSrcData.left;
	rtDecryptData.right = rtSrcData.right;
	rtDecryptData.top = rtEncryptData.bottom + 15;
	rtDecryptData.bottom = rtDecryptData.top + 25;
	m_editDecryptData.MoveWindow(rtDecryptData);
}
