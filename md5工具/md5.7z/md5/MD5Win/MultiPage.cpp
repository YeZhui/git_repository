// MultiPage.cpp : implementation file
//

#include "stdafx.h"
#include "MD5Win.h"
#include "MultiPage.h"
#include "afxdialogex.h"


// CMultiPage dialog

IMPLEMENT_DYNAMIC(CMultiPage, CPropertyPage)

CMultiPage::CMultiPage()
	: CPropertyPage(CMultiPage::IDD)
{

}

CMultiPage::~CMultiPage()
{
}

void CMultiPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_QUERY_BUTTON, m_buttonQuery);
}


BEGIN_MESSAGE_MAP(CMultiPage, CPropertyPage)
	ON_BN_CLICKED(IDC_QUERY_BUTTON, &CMultiPage::OnBnClickedQuery)
END_MESSAGE_MAP()

BOOL CMultiPage::OnInitDialog()
{
	CPropertyPage::OnInitDialog();
	RecalLayout();
	return TRUE;
}

void CMultiPage::OnBnClickedQuery()
{

}

void CMultiPage::RecalLayout(void)
{
		if (m_hWnd == NULL || !IsWindow(m_hWnd) )
		return;
	CPropertySheet *pSheet = dynamic_cast<CPropertySheet*>(GetParent());
	if (pSheet == NULL)
		return;
	CRect rtTab;
	pSheet->GetClientRect(&rtTab);
	rtTab.DeflateRect(-2, 0, -2, -2);
	pSheet->GetTabControl()->MoveWindow(&rtTab);

	CRect rtPage;
	rtPage.left = rtTab.left + 10;
	rtPage.top = rtTab.top + 25;
	rtPage.right = rtTab.right - 10;
	rtPage.bottom = rtTab.bottom - 10;
	MoveWindow(rtPage);

	CRect rtClient;
	GetClientRect(&rtClient);

	//IDC_PROMPT_ENTER
	CRect rtPromptEnter;
	rtPromptEnter.left = rtClient.left + 15;
	rtPromptEnter.right = rtPromptEnter.left + 200;
	rtPromptEnter.top = rtClient.top + 20;
	rtPromptEnter.bottom = rtPromptEnter.top + 25;
	GetDlgItem(IDC_PROMPT_ENTER)->MoveWindow(rtPromptEnter);
	//IDC_STRING
	CRect rtString;
	rtString.left = rtPromptEnter.left;
	rtString.right = rtClient.right/2 +  100;
	rtString.top = rtPromptEnter.top + 20;
	rtString.bottom = rtString.top + 25;
	GetDlgItem(IDC_STRING)->MoveWindow(rtString);
	//IDC_QUERY_BUTTON
	CRect rtQueryButton;
	rtQueryButton.left = rtString.right + 10;
	rtQueryButton.right = rtQueryButton.left + 75;
	rtQueryButton.top = rtString.top;
	rtQueryButton.bottom = rtString.bottom;
	GetDlgItem(IDC_QUERY_BUTTON)->MoveWindow(rtQueryButton);
	//IDC_LIST__RESULT
	CRect rtListResult;
	rtListResult.left = rtString.left;
	rtListResult.right = rtQueryButton.right;
	rtListResult.top = rtString.bottom + 15;
	rtListResult.bottom = rtClient.bottom - 100;
	GetDlgItem(IDC_LIST__RESULT)->MoveWindow(rtListResult);
}
// CMultiPage message handlers
