// AddSheet.cpp : implementation file
//

#include "stdafx.h"
#include "MD5Win.h"
#include "AddSheet.h"


// CAddSheet

IMPLEMENT_DYNAMIC(CAddSheet, CPropertySheet)

CAddSheet::CAddSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
	, m_convertPage(new CConvertPage())
	, m_multiPage(new CMultiPage())
{
	AddPage(m_convertPage);
	AddPage(m_multiPage);
}

CAddSheet::CAddSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
	, m_convertPage(new CConvertPage())
	, m_multiPage(new CMultiPage())
{
	AddPage(m_convertPage);
	AddPage(m_multiPage);
}

CAddSheet::~CAddSheet()
{
	SAFE_DELETE(m_convertPage);
	SAFE_DELETE( m_multiPage);
}

void CAddSheet::OnSize(UINT nType, int cx, int cy)
{
	if (m_convertPage != NULL)
		m_convertPage->RecalLayout();

	if (m_multiPage != NULL)
		m_multiPage->RecalLayout();

	CPropertySheet::OnSize(nType, cx, cy);
}

BEGIN_MESSAGE_MAP(CAddSheet, CPropertySheet)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CAddSheet message handlers
