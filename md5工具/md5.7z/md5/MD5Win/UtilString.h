#pragma once

#include <string>
#include <vector>
//#include "selflib_dll.h"
//#define  SELFLIB_DLL
//#include <WTypes.h>

typedef std::vector<std::string> VecStr;

namespace UtilString{
  std::wstring ConvertMultiByteToWideChar(const std::string& strSrc);
  std::wstring ConvertMultiByteToWideCharUTF8(const std::string& strSrc);

  std::string ConvertWideCharToMultiByte(const std::wstring& wstrSrc);
  std::string ConvertWideCharToMultiByteUTF8(const std::wstring& wstrSrc);

  bool  ConvertHexStringToValue(const std::string& str, int& value) ;


  void ChangeStringLetter(std::string& str, bool fToUp);

  bool SplitString(const std::string& strSrc, VecStr& vecStrDest, const std::string& strMark=",");
}
