#pragma once


// CMultiPage dialog

class CMultiPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CMultiPage)

public:
	CMultiPage();
	virtual ~CMultiPage();

// Dialog Data
	enum { IDD = IDD_MD5WIN_MULTI };

	virtual void RecalLayout(void);
	virtual	BOOL OnInitDialog();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg void OnBnClickedQuery();

	DECLARE_MESSAGE_MAP()
private:
	CButton       m_buttonQuery;
};
